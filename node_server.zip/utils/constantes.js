const default_login = 'odc'
const default_password = '7112022'

module.exports = {
    default_login,
    default_password
};